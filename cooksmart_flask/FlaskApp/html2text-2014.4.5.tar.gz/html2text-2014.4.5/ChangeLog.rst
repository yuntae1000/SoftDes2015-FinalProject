2014.4.5 - 2014-04-05
=====================
----

* Fix #1: Add ``ChangeLog.rst`` file.
* Fix #2: Add ``AUTHORS.rst`` file.
