``html2text`` was Originally written by Aaron Swartz.

The AUTHORS are (and/or have been):

    * Aaron Swartz
    * Alireza Savand
    * Yariv Barkan
    * Alex Musayev
    * Matěj Cepl
    * Stefano Rivera

Maintainer:

    * Alireza Savand
